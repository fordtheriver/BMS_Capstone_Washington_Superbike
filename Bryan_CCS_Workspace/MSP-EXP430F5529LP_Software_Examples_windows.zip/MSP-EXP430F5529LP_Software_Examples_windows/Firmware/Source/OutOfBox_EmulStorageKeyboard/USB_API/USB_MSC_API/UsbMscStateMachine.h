/* 
 * ======== UsbMscStateMachine.h ========
 */
#ifndef _USB_MSCSTATE_H_
#define _USB_MSCSTATE_H_

#ifdef __cplusplus
extern "C"
{
#endif

//this file is obsolete. To delete in next version.

#ifdef __cplusplus
}
#endif
#endif  //_USB_MSCSTATE_H_

