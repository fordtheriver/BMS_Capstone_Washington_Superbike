//Declare function prototypes

void UARTinit();
void UARTprintstring(char *string);
void UARTprintchar(char *c);
char UARTreadchar();
