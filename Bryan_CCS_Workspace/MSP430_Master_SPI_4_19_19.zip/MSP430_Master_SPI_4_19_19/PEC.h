
void init_PEC15_Table();
uint16_t pec15 (uint8_t *data , int len);






